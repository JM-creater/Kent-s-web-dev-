function personalInfo()
{
  var lname = document.getElementById("lname").value;
  var fname = document.getElementById("fname").value;
  var mi = document.getElementById("mi").value;
  var age = parseInt(document.getElementById("age").value);
  var status = document.getElementById("status").value;
  var co = document.getElementById("co").value;
  var city = document.getElementById("city").value;
  var ciad = document.getElementById("ciad").value;
  var primeschool = document.getElementById("primeschool").value;
  var primeloc = document.getElementById("primeloc").value;
  var secondschool = document.getElementById("secondschool").value;
  var secondloc = document.getElementById("secondloc").value;
  var terschool = document.getElementById("terschool").value;
  var terdloc = document.getElementById("terloc").value;

  alert("First Name: " + fname
        + "\nLast Name " + lname
        + "\nMi: " + mi
        + "\nAge " + age
        + "\nStatus " + status
        + "\nState: " + co
        + "\nCity " + city
        + "\nCity Address " + ciad 
        + "\n\nPrimary School: " + primeschool
        + "\nSchool Location: " + primeloc
        + "\n\nSecondary School: " + secondschool
        + "\nSchool Location: " + secondloc 
        + "\n\nTertiary School: " + terschool
        + "\nSchool Location: " + terloc);

}
